package com.cookandroid.a0929;

import android.app.DatePickerDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.a0929.ui.fragment.DatePickDialog;
import com.cookandroid.a0929.ui.fragment.TimePickDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Date;
import java.text.SimpleDateFormat;


public class Schedule_pen extends AppCompatActivity  implements View.OnClickListener {
    long mNow;
    Date mDate;
    long dNow;
    Date dDate;
    SimpleDateFormat mFormat = new SimpleDateFormat("hh:mm");
    SimpleDateFormat dFormat = new SimpleDateFormat("MM월dd일");
    TextView start_hm_time;
    TextView start_day_time;
    TextView end_day_time;
    TextView end_hm_time;
    TextView bck_btn;
    TextView save_btn;


    private Animation fab_open, fab_close;
    private Boolean isFabOpen = false;
    private FloatingActionButton colorM, color1, color2,color3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_pen);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        start_day_time = (TextView) findViewById(R.id.schedule_pen_startdate_tv);
        start_hm_time = (TextView) findViewById(R.id.schedule_pen_starttime_tv);
        end_day_time = (TextView) findViewById(R.id.schedule_pen_enddate_tv);
        end_hm_time = (TextView) findViewById(R.id.schedule_pen_endtime_tv);
        bck_btn = (TextView) findViewById(R.id.schedule_pen_close_tv);
        save_btn = (TextView) findViewById(R.id.schedule_pen_save_tv);

        start_day_time.setText(getTimeD());
        end_day_time.setText(getTimeD());
        start_hm_time.setText(getTime());
        end_hm_time.setText(getTime());
        //플로팅버튼//
        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);
        colorM = (FloatingActionButton) findViewById(R.id.schedule_pen_colormain_fbtn);  colorM.setOnClickListener(this);
        color1 = (FloatingActionButton) findViewById(R.id.schedule_pen_color1_fbtn);  color1.setOnClickListener(this);
        color2 = (FloatingActionButton) findViewById(R.id.schedule_pen_color2_fbtn);  color2.setOnClickListener(this);
        color3 = (FloatingActionButton) findViewById(R.id.schedule_pen_color3_fbtn);  color3.setOnClickListener(this);
        //

        bck_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {finish();}
        });
        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {finish();}
        });


        start_day_time.setOnClickListener(new View.OnClickListener(){
            DatePickDialog pd = new DatePickDialog();
            @Override
            public void onClick(View view) {
                pd.setListener(d);
                pd.show(getSupportFragmentManager(), "YearMonthPickerTest");
            }
        });
        start_hm_time.setOnClickListener(new View.OnClickListener(){
            TimePickDialog pd = new TimePickDialog();
            @Override
            public void onClick(View view) {
                pd.setListener(d);
                pd.show(getSupportFragmentManager(), "YearMonthPickerTest");
            }
        });
        end_day_time.setOnClickListener(new View.OnClickListener(){
            DatePickDialog pd = new DatePickDialog();
            @Override
            public void onClick(View view) {
                pd.setListener(d);
                pd.show(getSupportFragmentManager(), "YearMonthPickerTest");
            }
        });
        end_hm_time.setOnClickListener(new View.OnClickListener(){
            TimePickDialog pd = new TimePickDialog();
            @Override
            public void onClick(View view) {
                pd.setListener(d);
                pd.show(getSupportFragmentManager(), "YearMonthPickerTest");
            }
        });
    }
    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth){
            Log.d("YearMonthPickerTest", "year = " + year + ", month = " + monthOfYear + ", day = " + dayOfMonth);
        }
    };
    private String getTimeD(){
        dNow = System.currentTimeMillis();
        dDate = new Date(dNow);
        return dFormat.format(dDate);
    }
    private String getTime(){
        mNow = System.currentTimeMillis();
        mDate = new Date(mNow);
        return mFormat.format(mDate);
    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.schedule_pen_colormain_fbtn:
                anim();
                break;
            case R.id.schedule_pen_color1_fbtn:
                anim();
                colorM.setBackgroundTintList(ColorStateList.valueOf(Color
                        .parseColor("#ff7a7cc4")));
                break;
            case R.id.schedule_pen_color2_fbtn:
                anim();
                colorM.setBackgroundTintList(ColorStateList.valueOf(Color
                        .parseColor("#ffff6600")));
                break;
            case R.id.schedule_pen_color3_fbtn:
                anim();
                colorM.setBackgroundTintList(ColorStateList.valueOf(Color
                        .parseColor("#ff259999")));
                break;
        }
    }

    public void anim() {

        if (isFabOpen) {
            color1.startAnimation(fab_open);
            color2.startAnimation(fab_open);
            color3.startAnimation(fab_open);
            color1.setClickable(false);
            color2.setClickable(false);
            color3.setClickable(false);
            isFabOpen = false;
        } else {
            color1.startAnimation(fab_close);
            color2.startAnimation(fab_close);
            color3.startAnimation(fab_close);
            color1.setClickable(true);
            color2.setClickable(true);
            color3.setClickable(true);
            isFabOpen = true;
        }
    }
}
