package com.cookandroid.a0929;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.cookandroid.a0929.DB.ValidateRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Pattern;


public class Log_sign_up extends AppCompatActivity {
    private EditText id, pw, email, checkpw, name;
    private TextView hintpw, hintname, hintid, hintemail, hintcheckpw;
    private boolean validate = false;
    private AlertDialog dialog;
    Pattern p = Patterns.EMAIL_ADDRESS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_sign);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        id = (EditText) findViewById(R.id.log_sign_id_tet);
        name = (EditText) findViewById(R.id.log_sign_name_tet);
        email = (EditText) findViewById(R.id.log_sign_email_tet);
        pw = (EditText) findViewById(R.id.log_sign_pw_tet);
        checkpw = (EditText) findViewById(R.id.log_sign_pwcheck_tet);
        hintpw = (TextView) findViewById(R.id.log_sign_pwerr_tv);
        hintid = (TextView) findViewById(R.id.log_sign_iderr_tv);
        hintname = (TextView) findViewById(R.id.log_sign_nameerr_tv);
        hintemail = (TextView) findViewById(R.id.log_sign_emailerr_tv);
        hintcheckpw = (TextView) findViewById(R.id.log_sign_pwcheckerr_tv);


        Button btn = (Button) findViewById(R.id.log_sign_finish_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String checkid = id.toString();
//                Intent intent = new Intent(find_pwd.this, MainActivity.class);
//                startActivity(intent);
                //판별했을때 true 인경우 값 php로 넘기고 종료
                if (id.getText().toString().length() == 0){
                    hintid.setVisibility(0);
                    id.requestFocus();
                }else if(id.getText().toString().length() < 4){
                    hintid.setVisibility(0);
                    hintid.setText("ID가 너무 짧습니다.");
                    id.requestFocus();
                    return;
                }
                if(validate){
                    return;
                }
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if (success) {
                                hintid.setText("사용가능한 ID입니다.");
                                validate = true; //검증 완료

                            }
                            else {
                                hintid.setText("이미 존재하는 ID입니다.");
                                id.requestFocus();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        System.out.println("hongchul" +validate);
                    }
                };
                ValidateRequest validateRequest = new ValidateRequest(checkid, responseListener);
                RequestQueue queue = Volley.newRequestQueue(Log_sign_up.this);
                queue.add(validateRequest);

                if (name.getText().toString().length() == 0){
                    hintname.setVisibility(0);
                    name.requestFocus();
                    return;
                }

                if (email.getText().toString().length() == 0){
                    hintemail.setVisibility(0);
                    hintemail.setText("Email을 입력해 주세요");
                    email.requestFocus();
                } else if (!p.matcher(email.getText().toString()).matches()){
                    hintemail.setVisibility(0);
                    email.requestFocus();
                    return;
                }

                if (pw.getText().toString().length() == 0){
                    hintpw.setVisibility(0);
                    pw.requestFocus();
                    return;
                }

                if (checkpw.getText().toString().length() == 0){
                    hintcheckpw.setVisibility(0);
                    checkpw.requestFocus();
                    return;
                }
            }
        });
    }

}