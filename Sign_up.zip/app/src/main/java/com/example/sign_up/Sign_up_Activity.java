package com.example.sign_up;

import android.os.Bundle;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputEditText;

public class Sign_up_Activity extends MainActivity {
    private EditText user_id,user_name,user_email,user_pwd,user_check_pwd;
    private Button btn_register;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        user_id = findViewById(R.id.user_id);
        user_name = findViewById(R.id.user_name);
        user_email = findViewById(R.id.user_email);
        user_pwd = findViewById(R.id.user_pwd);
        user_check_pwd = findViewById(R.id.user_check_pwd);
    }
}

