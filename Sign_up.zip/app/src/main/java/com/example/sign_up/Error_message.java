package com.example.sign_up;

import android.os.Bundle;
import android.widget.Spinner;
import android.widget.TextView;

public class Error_message extends MainActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }

}
