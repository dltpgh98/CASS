package com.example.sign_up;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

//import android.graphics.Color;
import android.view.View;
import android.widget.Button;
//import android.widget.TextView;
//import android.text.Spannable;
//import android.text.SpannableString;
//import android.text.style.ForegroundColorSpan;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

//        //logo color
//        TextView cass = findViewById(R.id.cass);
//        String content = cass.getText().toString();
//        SpannableString spannableString = new SpannableString(content);
//
//        String word = "A";
//        int start = content.indexOf(word);
//        int end = start + word.length();
//
//        spannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#FFB1DB")), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//        cass.setText(spannableString);//font relay on activity_main
//        <TextView
//
//        android:layout_width="match_parent"
//        android:layout_height="wrap_content"
//        android:text="@string/Logo"
//        android:fontFamily="@font/fontstyle"
//        android:textSize="30sp"
//        android:textColor="@color/black"
//        android:gravity="center"
//        android:layout_marginStart="150dp"
//        android:layout_marginEnd="150dp"
//        android:layout_marginTop="50dp"
//        app:layout_constraintStart_toStartOf="parent"
//        app:layout_constraintTop_toTopOf="parent"/>


                Button backBtn = (Button)findViewById(R.id.Back_button);
        backBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                finish(); // 그전 페이지로 돌아갈 코드
            }
        });


        Button okBtn = (Button) findViewById(R.id.ok_button);
        okBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View view){

            }
        });


    }
}